$(document).ready(function () {

  // ALERTA SOLO UNA VEZ
  if (!localStorage.getItem("bienvenida")) {
    alert("Bienvenido a CinePlus 🎬");
    localStorage.setItem("bienvenida", "true");
  }

  $("#lista-peliculas").html('<div class="text-center"><div class="spinner-border"></div></div>');

  setTimeout(() => {
    $.getJSON("data/peliculas.json", function (peliculas) {
      let html = "";

      peliculas.forEach(peli => {

        let hoy = new Date();
        let estreno = new Date(peli.estreno);

        let esEstreno = hoy <= estreno;
        let precio = esEstreno ? peli.precios.estreno : peli.precios.normal;

        let badge = esEstreno
          ? `<span class="badge bg-danger">Estreno $${precio}</span>`
          : `<span class="badge bg-success">Normal $${precio}</span>`;

        html += `
        <div class="col-md-4 pelicula" style="display:none;">
          <div class="card h-100 shadow">
            <img src="img/${peli.imagen}" class="card-img-top">
            <div class="card-body">
              <h5>${peli.titulo}</h5>
              ${badge}<br><br>

         <div class="d-grid gap-2">
  <a href="pages/detalle.html?id=${peli.id}" class="btn btn-primary">Ver más</a>
  <a href="pages/renta.html?id=${peli.id}" class="btn btn-success">Rentar 🍿</a>
  <button class="btn btn-danger verTrailer" data-trailer="${peli.trailer}">
                Tráiler
              </button>
</div>
              
            </div>
          </div>
        </div>`;
      });

      $("#lista-peliculas").html(html);
      $(".pelicula").fadeIn();

    });
  }, 5000);

});

// ABRIR TRAILER
$(document).on("click", ".verTrailer", function () {
  let url = $(this).data("trailer");

  $("#iframeTrailer").attr("src", url);
  $("#trailerOverlay").removeClass("d-none");
});

// CERRAR TRAILER
$("#cerrarTrailer").click(function () {
  $("#trailerOverlay").addClass("d-none");
  $("#iframeTrailer").attr("src", "");
});